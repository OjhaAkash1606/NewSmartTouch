export const dropDown = [
  {
    title: 'OptionChart',
    to: '/OptionChart'
  },
  {
    title: 'Market Watch',
    to: '/MarketWatch'
  },
  {
    title: 'Orderbook',
    to: '/Orderbook'
  },
  {
    title: 'Order Window',
    to: '/Orderwindow'
  },
  {
    title: 'RearrangeOrder',
    to: '/RearrangeOrder'
  },
  {
    title: 'positions',
    to: '/positions'
  },
  {
    title: 'StrategyBuilder',
    to: '/StrategyBuilder'
  },
  {
    title: 'Dashboard',
    to: '/dashboard'
  },
  {
    title: 'Screener',
    to: '/Screener'
  },
  {
    title: 'Niftyheatmap',
    to: '/Niftyheatmap'
  }
];
