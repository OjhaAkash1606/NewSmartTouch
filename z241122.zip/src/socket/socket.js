let url = 'ws://www.tradingcampus.net';

export const server_socket = {
  interactive_socket: `${url}:17001`,
  brodcast_socket: `${url}:17002`,
  strategt_socket: `${url}:17003`
};
